using System.Collections.Generic;
using System.Linq;
using FirstAspNetWebApi.Controllers;
using FirstAspNetWebApi.Models;

namespace FirstAspNetWebApi
{
    public class ProductContext
    {
        private static readonly List<Product> Products = new List<Product>();

        static ProductContext()
        {
            Products.Add(new Product() {Id = 1, Name = "Phone"});
            Products.Add(new Product() {Id = 2, Name = "Table"});
            Products.Add(new Product() {Id = 3, Name = "Book"});
        }

        public Product GetProduct(int id)
        {
            var product = Products.Find(p => p.Id == id);
            return product;
        }

        public IEnumerable<Product> GetProducts()
        {
            return Products;
        }

        public Product AddProduct(Product p)
        {
            Products.Add(p);
            return p;
        }

        public void Delete(int id)
        {
            var product = Products.FirstOrDefault(p => p.Id == id);
            if (product != null)
            {
                Products.Remove(product);
            }
        }

        public bool Update(int id, Product product)
        {
            Product rProduct = Products.FirstOrDefault(p => p.Id == id);
            if (rProduct != null)
            {
                rProduct = product;
                return true;
            }
            return false;
        }
    }
}