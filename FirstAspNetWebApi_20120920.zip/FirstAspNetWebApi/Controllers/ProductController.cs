﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using FirstAspNetWebApi.Models;

namespace FirstAspNetWebApi.Controllers
{
    public class ProductController : ApiController
    {
        private readonly ProductContext _repository = new ProductContext();

        // GET api/product
        public IEnumerable<Product> Get()
        {
            return _repository.GetProducts();
        }

        // GET api/product/5
        public Product Get(int id)
        {
            Product product = _repository.GetProduct(id);

            if (product == null)
            {
                throw new HttpResponseException(
                    Request.CreateResponse(HttpStatusCode.NotFound));
            }
            else
            {
                return product;
            }
        }

        public Product GetByName(string name)
        {
            var products = _repository.GetProducts();
            var product = products.FirstOrDefault(p => p.Name.ToLower() == name.ToLower());

            if (product == null)
            {
                throw new HttpResponseException(
                    Request.CreateResponse(HttpStatusCode.NotFound));
            }
            else
            {
                return product;
            }
        }

        // POST api/product  
        public HttpResponseMessage Post(Product product)
        {
            if (ModelState.IsValid)
            {
                // this will set the ID for instance...
                product = _repository.AddProduct(product);

                /*
                * 1. The client should send a POST request to /user to create the resource.
                * 2. The server should then return a 201 CREATED response, with the URI of 
                * the resource in the Location header.
                * */

                var response = Request.CreateResponse(HttpStatusCode.Created, product);

                string uri = Url.Link("DefaultApi", new {id = product.Id});
                response.Headers.Location = new Uri(uri);
                return response;
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        // PUT api/product/5
        public HttpResponseMessage Put(int id, Product product)
        {
            if (ModelState.IsValid && id == product.Id)
            {
                var result = _repository.Update(id, product);
                if (result == false)
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound);
                }
                return Request.CreateResponse(HttpStatusCode.OK);
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        // DELETE api/product/5
        public HttpResponseMessage Delete(int id)
        {
            Product product = _repository.GetProduct(id);

            if (product == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            try
            {
                _repository.Delete(id);
            }
            catch (Exception exc)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            return Request.CreateResponse(HttpStatusCode.OK, product);
        }
    }
}